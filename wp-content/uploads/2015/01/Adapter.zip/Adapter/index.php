<?php get_header(); ?>

<!-- Начало врапер -->
<section id="wrapper">
<div id="middle">
<div id="content">
<div id="colLeft">

<?php if(get_option('alltuts_showsticky') == 'yes'){?>
<!--########## Начало большого блока! ##########-->
<?php if ((is_front_page()) and (!is_paged())) { ?>
<div class="polosa">
<h2>Основное</h2>
</div>

<?php
query_posts(array('post__in'=>get_option('sticky_posts')));
?>

<?php while (have_posts()) : the_post(); ?>

<article class="postBoxbig">

<div class="postThumbbig"><a href="<?php the_permalink() ?>"><?php the_post_thumbnail(790,450); ?></a></div>

<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>

<div class="info"> 
<?php the_time('j') ?> <?php the_time('M') ?> <?php the_time('Y') ?> / <?php the_tags('', ', ', ''); ?> / <?php comments_popup_link('Комментариев 0', '1 комментарий', 'Комментариев %'); ?>
</div>

<div class="textPreview">
<?php the_excerpt(); ?>
</div>

<div class="more-link"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">Далее >></a></div>

</article>
<?php endwhile; ?>
<?php wp_reset_query(); ?>


<?php } ?>
<!--########## Конец большого блока! ########## -->
<?php }?>

<div class="lastppolosa">
<h2>Последние посты</h2>
</div>

<!--########## Начало последних постов  ############-->

<?php
query_posts(array('post__not_in'=>get_option('sticky_posts'),
'paged' => get_query_var('paged')));
?>

<?php if (have_posts()) : ?>
<?php $first = true; ?>
<?php while (have_posts()) : the_post(); ?>

<!-- Начало .postBox -->

<article class="postBox <?php if($first == true) echo "first" ?>" id="postBox-<?php the_ID(); ?>">

<div class="postThumbbig"><a href="<?php the_permalink() ?>"><?php the_post_thumbnail(); ?></a></div>

<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>

<div class="info"> 
<?php the_time('j') ?> <?php the_time('M') ?> <?php the_time('Y') ?> / <?php the_tags('', ', ', ''); ?> / <?php comments_popup_link('Комментариев 0', '1 комментарий', 'Комментариев %'); ?>
</div>

<div class="textPreview">
<?php the_excerpt(); ?>
</div>

<div class="more-link"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">Далее >></a></div>

</article>

<!-- Конец .postBox -->

<?php $first = !$first; if ($first) echo '<br clear=all>'; ?>

<?php endwhile; ?>

<?php wp_reset_query(); ?>
<!--########## Конец последних постов  ############-->

<?php else : ?>

<h1>А здесь нет ничего :( 404 </h1>
                
<?php endif; ?>

<!--<div class="navigation">
						<div class="alignleft"><?php next_posts_link() ?></div>
						<div class="alignright"><?php previous_posts_link() ?></div>
			</div>-->
			<?php if (function_exists("emm_paginate")) {
				emm_paginate();
			} ?>

<!--########## Начало постов по категориям  ############-->

<div class="polosacat">
<h2>По категориям</h2>
</div>

<div id="firstcat" class="postBoxcat">

<ul>
<?php $recent = new WP_Query("cat=2&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
<li>
<a href="<?php the_permalink() ?>"><?php the_post_thumbnail('loopThumb'); ?></a>
<a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
<p><?php the_time('j') ?> <?php the_time('M') ?> <?php the_time('Y') ?> / <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">Посмотреть</a></p>
</li>
<?php endwhile; ?>				
</ul>
			
</div>

<div class="postBoxcat">

<ul>
<?php $recent = new WP_Query("cat=3&showposts=5"); while($recent->have_posts()) : $recent->the_post();?>
<li>
<a href="<?php the_permalink() ?>"><?php the_post_thumbnail('loopThumb'); ?></a>
<a href="<?php the_permalink() ?>"><?php the_title(); ?></a>
<p><?php the_time('j') ?> <?php the_time('M') ?> <?php the_time('Y') ?> / <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>">Посмотреть</a></p>
</li>
<?php endwhile; ?>				
</ul>
			
</div>

<!--########## Конец постов по категориям  ############-->

		</div>
		<!-- Конец #colLeft -->
		
<?php get_sidebar(); ?>	
<?php get_footer(); ?>
