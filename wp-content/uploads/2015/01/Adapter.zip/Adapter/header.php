<!doctype html>

<!--[if IE]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<html lang=ru>
<head profile="http://gmpg.org/xfn/11">

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="keywords" content="<?php echo get_option('alltuts_keywords'); ?>" />
<meta name="description" content="<?php echo get_option('alltuts_description'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/style.css" />

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/arrow-up.js"></script>
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.form.js"></script>

<!-- Begin #bottomMenu -->

<script type="text/javascript">

$(function() {
			//We initially hide the all dropdown menus
			$('#dropdown_nav li').find('.sub-menu').hide();

			//When hovering over the main nav link we find the dropdown menu to the corresponding link.
			$('#dropdown_nav li').hover(function() {
				//Find a child of 'this' with a class of .sub_nav and make the beauty fadeIn.
				$(this).find('.sub-menu').fadeIn(400);
			}, function() {
				//Do the same again, only fadeOut this time.
				$(this).find('.sub-menu').fadeOut(100);
			});
		});

</script>

<script type="text/javascript">

/* использование: <a class='scrollTop' href='#' style='display:none;'></a>
	------------------------------------------------- */
	$(function(){
		var e = $(".scrollTop");
		var	speed = 5000;

		e.click(function(){
			$("html:not(:animated)" +( !$.browser.opera ? ",body:not(:animated)" : "")).animate({ scrollTop: 0}, 2500 );
			return false; //важно!
		});
		//появление
		function show_scrollTop(){
			( $(window).scrollTop()>300 ) ? e.fadeIn(300) : e.hide();
		}
		$(window).scroll( function(){show_scrollTop()} ); show_scrollTop();
	});

</script>

<?php wp_head(); ?>

</head>
<body>

<header>
<div id="headerInnertop">

<nav class="topMenuRight">
      
<?php if ( function_exists( 'wp_nav_menu' ) ){
					wp_nav_menu( array( 'theme_location' => 'secondary-menu','fallback_cb'=>'secondarymenu') );
				}else{
					secondarymenu();
			}?> 
    
</nav>

<div class="sharenew">

<?php if(get_option('alltuts_google_link')!=""){ ?>
<a class="icon-Google" href="<?php echo get_option('alltuts_google_link'); ?>" title="Я в Google+" target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_twitter_user')!=""){ ?>
<a class="icon-twitter" href="http://twitter.com/<?php echo get_option('alltuts_twitter_user'); ?>" title="Следить в Twitter!" target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_vk_link')!=""){ ?>
<a class="icon-vk" href="<?php echo get_option('alltuts_vk_link'); ?>" title="Я вКонтакте" target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_rss_link')!=""){ ?>
<a class="icon-rss" href="<?php echo get_option('alltuts_rss_link'); ?>" title="Подписаться на rss"  target="_blank"></a>
<?php }?>

<?php if(get_option('alltuts_facebook_link')!=""){ ?>
<a class="icon-facebook" href="<?php echo get_option('alltuts_facebook_link'); ?>" title="Я на facebook" target="_blank"></a>
<?php }?>

</div>
</div><!-- Конец верхнего блока -->

<!-- Блок с логотипом -->
<div id="headerInnerdown">

<!-- Начало логотипа -->

<div class="logo">
<a href="<?php bloginfo('url'); ?>"><img src="<?php echo get_option('alltuts_logo_img'); ?>" alt="<?php echo get_option('alltuts_logo_alt'); ?>"/></a>

</div>
<!-- Конец логотипа -->

</div><!-- Конец блока с логотипом -->

<!-- Begin #bottomMenu -->

<div class="bottomMenubg">
<div id="bottomMenublock">
<div class="bottomMenuhomelink">
<a  href="<?php bloginfo('url'); ?>"></a>
</div>

<nav>
<?php if ( function_exists( 'wp_nav_menu' ) ){
					wp_nav_menu( array( 'theme_location' => 'primary-menu', 'container_id' => 'dropdown_nav', 'container_class' => 'bottomMenu', 'fallback_cb'=>'primarymenu') );
				}else{
					primarymenu();
			}?>
           <!-- Конец #bottomMenu -->
</nav>
</div></div>
</header>
<!-- Конец хидер -->

<?php if(get_option('alltuts_strup') == 'yes'){?>
<a class='scrollTop' href='#'></a>
<?php }?>